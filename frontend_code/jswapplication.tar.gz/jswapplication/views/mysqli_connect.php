<?php
DEFINE('DB_USER','web');
DEFINE('DB_PASSWORD','W3bU$er!89');
DEFINE('DB_HOST','localhost');
DEFINE('DB_NAME','suvetracg');

$connect=@mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME)
or die('Could not connect to mysql'.mysqli_connect_error());
 
class Connection {
    function getConnection(){
        $host       = "localhost";
        $username   = "web";
        $password   = "W3bU$er!89";
        $dbname     = "suvetracg";

        try{
            $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $conn;
        }catch (Exception $e){
            echo $e->getMessage();
        }
    }
}
?>
