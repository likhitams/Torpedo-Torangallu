<?php 
foreach ($result as $r){
?>
<p id="shake_text" style="width:100% !important;"><span class="text-danger"><strong><?php echo $r->ladle_no?></strong></span>   <strong> Service is due on  </strong><strong><?php echo $r->service_date?></strong></p>
<?php 
}
?>
<br>
 
<h4 class="text-danger">Empty Torpedo Signal Alerts:</h4>
<?php
 include 'mysqli_connect.php';
 
 $query=mysqli_query($connect,"SELECT REPLACE(TRACKID, 'TORPEDO', 'TRACK') as trackno,DATE_FORMAT(INSERT_DT,'%d-%m-%Y %H:%i:%s') as TIME from TLC_GPS_LATEST group by INSERT_DT order by INSERT_DT DESC LIMIT 6");
while ($row = mysqli_fetch_array($query))  
{
?>
	<p id="shake_text" style="width:100% !important;">  <strong>Empty Torpedo Signal for TrackID :  </strong> <span class="text-danger"><strong><?php echo $row[0]; ?></strong></span> <strong>  Ready to Go.. Time @ <?php echo $row["TIME"]; ?></strong> </p>
<?php 
}
?>

 
