<link rel="shortcut icon" href="<?php echo asset_url()?>images/icon.png" type="image/png" />

	<style>
	
	#myCheckbox{
	    float: left;
	    margin-left: -589%;
	}
	
	#myCheckboxunit {
	    float: left;
	    margin-left: -484%;
	}
	
	.textAlign{
   			text-align: center;
   		}
   		.textAlignRight{
   			text-align: right;
   		}
   		
   		.textAlignLeft{
   			text-align: left;
   		}
             .adjustPanel{
                margin-left: 26px;
             }
		.ag-row{
			cursor: pointer;
		}
		.user-ignoff
	{
	    background-color: #C5D9F1;
	}
	.user-moving
	{
	    background-color: #66FF66;
	}
	.user-sudden
	{
	    background-color: #FF9999;
	}
	.user-illegal
	{
	    background-color: #D8D8D8;
	}
	.user-ignon
	{
	    background-color: #DBE5F1;
	}
	.user-overspeed
	{
	    background-color: #CCC0DA;
	}
	.user-slowidle
	{
	    background-color: #FDE9D9;
	}
	.user-unreachable
	{
	    background-color: #B2B2B2;
	}
	</style>